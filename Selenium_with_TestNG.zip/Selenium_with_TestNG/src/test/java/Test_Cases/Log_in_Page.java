package Test_Cases;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import Methods.utility.All_the_Method_For_JS;
import Methods.utility.Explicity_Wait;
import Methods.utility.ReadExcel2;
import Methods.utility.Read_Excel;
import Methods.utility.Take_screenshot;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Log_in_Page {
	@Test
	public void page() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Eclipse\\eclipse\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.saucedemo.com/");
		driver.manage().window().maximize();
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		driver.findElement(By.id("login-button")).click();
		WebElement addcart=driver.findElement(By.id("add-to-cart-sauce-labs-backpack"));
		WebElement button=driver.findElement(By.id("react-burger-menu-btn"));
		WebElement scrollView=driver.findElement(By.id("add-to-cart-sauce-labs-onesie"));
		Thread.sleep(5000);
		All_the_Method_For_JS.java_script_Executor(addcart,driver);
		All_the_Method_For_JS.draw_boder(addcart,driver);
		All_the_Method_For_JS.clickButtonByJS(button, driver);
		//All_the_Method_For_JS.Scrool_up(driver); 
		All_the_Method_For_JS.Scrool_View(scrollView, driver);
		Thread.sleep(5000);
		driver.getTitle();
		driver.quit();
		
	}
	@Test
	public void DropDown() {
		System.setProperty("webdriver.chrome.driver", "C:\\Eclipse\\eclipse\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.saucedemo.com/");
		driver.manage().window().maximize();
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		driver.findElement(By.id("login-button")).click();
		WebElement dropdown=driver.findElement(By.className("product_sort_container"));
		Select select=new Select(dropdown);
		List<WebElement> options=select.getOptions();
		for(WebElement option : options  ) {
			System.out.println(option);
		}
		
		driver.quit();
		
	}
	@Test
    public void Webtable() throws IOException {
		System.setProperty("webdriver.chrome.driver", "C:\\Eclipse\\eclipse\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://demoqa.com/webtables");
		driver.manage().window().maximize();
		int row=driver.findElements(By.xpath("//*[@id='app']/div/div/div[2]/div[2]/div[2]/div[3]/div[1]/div[2]/div")).size();
		int col=driver.findElements(By.xpath("//*[@id='app']/div/div/div[2]/div[2]/div[2]/div[3]/div[1]/div[2]/div[1]/div/div")).size();
		System.out.println(row+"  "+col);
		for(int i=1;i<=row;i++) {
			for(int j=1;j<=col;j++) {
				System.out.print(driver.findElement(By.xpath("//*[@id='app']/div/div/div[2]/div[2]/div[2]/div[3]/div[1]/div[2]/div["+i+"]/div/div["+j+"]")).getText()+"  ");
			}
			System.out.println();
		}
		Take_screenshot.screenshot(driver);
		driver.quit();
    }
	@Test
	public void calender() {
		System.setProperty("webdriver.chrome.driver", "C:\\Eclipse\\eclipse\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://demoqa.com/automation-practice-form");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@id='dateOfBirthInput']")).click();
		Select select=new Select(driver.findElement(By.xpath("//*[@id='dateOfBirth']/div[2]/div[2]/div/div/div[2]/div[1]/div[2]/div[1]/select")));
		select.selectByVisibleText("July");
		
		
		
	}
	@Test
	public void Wait_Function() {
		System.setProperty("webdriver.chrome.driver", "C:\\Eclipse\\eclipse\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://demoqa.com/buttons");
		driver.manage().window().maximize();
		WebElement click=driver.findElement(By.id("G4Dh5"));
		Explicity_Wait.explictwait(driver,click, Duration.ofSeconds(5));
		driver.quit();
	}
	@Test
	public void Window_handdles() {
		System.setProperty("webdriver.chrome.driver", "C:\\Eclipse\\eclipse\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://demoqa.com/browser-windows");
		driver.manage().window().maximize();
		driver.findElement(By.id("tabButton")).click();
		String parentWindow=driver.getWindowHandle();
		Set<String> windows=driver.getWindowHandles();
		Iterator<String> iterator=windows.iterator();
		while(iterator.hasNext()) {
			String ChildWindow=iterator.next();
			if(!parentWindow.equalsIgnoreCase(ChildWindow)) {
				driver.switchTo().window(ChildWindow);
				System.out.println(driver.findElement(By.id("sampleHeading")).getText());
			}
		}
		driver.quit();
	}
	@Test
	public void Alert() {
		System.setProperty("webdriver.chrome.driver", "C:\\Eclipse\\eclipse\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://demoqa.com/alerts");
		driver.manage().window().maximize();
		driver.findElement(By.id("alertButton")).click();
		driver.switchTo().alert().accept();
		driver.findElement(By.id("timerAlertButton")).click();
		Explicity_Wait.alertpresent(driver, Duration.ofSeconds(10));
		driver.findElement(By.id("confirmButton")).click();
		driver.switchTo().alert().dismiss();
		driver.quit();
		}
	@Test
	public void ReadData() throws IOException {
		String path="C:\\Eclipse\\credentials.xlsx";
		String sheetname="Sheet1";
		Read_Excel.ExcelReader(path, sheetname);
		ReadExcel2.ExcelReaderx(path, sheetname);
	}
	@Test
	public void HandlessWindowHanddle() {
		WebDriver unitDriver=new HtmlUnitDriver();
		unitDriver.get("https://www.saucedemo.com/");
		unitDriver.findElement(By.id("user-name")).sendKeys("standard_user");
		unitDriver.findElement(By.id("password")).sendKeys("secret_sauce");
		unitDriver.findElement(By.id("login-button")).click();
		WebElement dropdown=unitDriver.findElement(By.className("product_sort_container"));
		Select select=new Select(dropdown);
		List<WebElement> options=select.getOptions();
		for(WebElement option : options  ) {
			System.out.println(option);
		}
		
		unitDriver.quit();
	}
	@Test
    public void BrokenLink() throws MalformedURLException, IOException {
    	System.setProperty("webdriver.chrome.driver", "C:\\Eclipse\\eclipse\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://demoqa.com/broken");
		driver.manage().window().maximize();
		List<WebElement> linklist=driver.findElements(By.tagName("a"));
		linklist.addAll(driver.findElements(By.tagName("img")));
		System.out.println("The size of link --->"+linklist.size());
		List<WebElement> activeLink=new ArrayList<WebElement>();
		for(int i=0;i<linklist.size();i++) {
		if(linklist.get(i).getAttribute("href")!=null && (!linklist.get(i).getAttribute("href").contains("javascript"))) {
			activeLink.add(linklist.get(i));
		}
		}
		System.out.println("The size of activelink --->"+activeLink.size());
		for(int j=0;j<activeLink.size();j++) {
			HttpURLConnection connection=(HttpURLConnection)new URL(activeLink.get(j).getAttribute("href")).openConnection();
			connection.connect();
			String response=connection.getResponseMessage();
			connection.disconnect();
			System.out.println(activeLink.get(j).getAttribute("href")+"----->"+response);
		}
		driver.quit();
    }
	
}
