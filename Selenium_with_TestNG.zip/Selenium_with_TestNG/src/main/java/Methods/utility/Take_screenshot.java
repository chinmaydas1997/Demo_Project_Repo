package Methods.utility;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Take_screenshot {
	public static void screenshot(WebDriver driver) throws IOException {
		File file=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(file,new File("C:\\Java_Program\\Selenium_with_TestNG\\Screenshot_data\\screensgot.jpg"));
		
	}

}
