package Methods.utility;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel2 {
  public static void ExcelReaderx(String path,String sheetname) throws IOException {
	  FileInputStream fs=new FileInputStream(path);
	  Workbook book=new XSSFWorkbook(fs);
	  Sheet sheet=book.getSheet(sheetname);
	  int row=sheet.getLastRowNum();
	  int col=sheet.getRow(row).getLastCellNum();
	  System.out.println("Number of rows:"+row+" and number of columns:"+col);
	  for(int i=1;i<row;i++) {
		  Row currentrow=sheet.getRow(i);
		  for(int j=0;j<col;j++) {
			  String value=currentrow.getCell(j).toString();
			  System.out.println(" "+value);
		  }
		  System.out.println();
	  }
	  
  }
}
