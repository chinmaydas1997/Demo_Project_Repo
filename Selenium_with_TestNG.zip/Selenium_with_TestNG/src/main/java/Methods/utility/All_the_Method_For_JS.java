package Methods.utility;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class All_the_Method_For_JS {
	
	public static void java_script_Executor(WebElement element,WebDriver driver) {
		JavascriptExecutor je=((JavascriptExecutor)driver);
		String bgcolor= element.getCssValue("backgroundColor");
		for(int i=0;i<100;i++) {
			Changecolour("rgb(0,200,0)",element,driver);
			Changecolour(bgcolor,element,driver);
		}
		
	}
	
	public static void Changecolour(String color, WebElement element,WebDriver driver) {
		JavascriptExecutor js=((JavascriptExecutor)driver);
		js.executeScript("arguments[0].style.backgroundColor='"+color+"'",element);
	}
	
	public static void draw_boder(WebElement element,WebDriver driver) {
		JavascriptExecutor js=((JavascriptExecutor)driver);
		js.executeScript("arguments[0].style.border='3px solid red'", element);
		
	}
	public static void clickButtonByJS(WebElement element, WebDriver driver) {
		JavascriptExecutor js=((JavascriptExecutor)driver);
		js.executeScript("arguments[0].click()", element);
	}
	public static void Scrool_up(WebDriver driver) {
		JavascriptExecutor js=((JavascriptExecutor)driver);
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
	}
	public static void Scrool_View(WebElement element,WebDriver driver) {
		JavascriptExecutor js=((JavascriptExecutor)driver);
		js.executeScript("arguments[0].scrollIntoView(true);",element);
	}

}
