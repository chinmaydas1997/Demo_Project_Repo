package Methods.utility;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.apache.poi.ss.usermodel.Cell;

public class Read_Excel {
	public static void ExcelReader(String filepath,String SheetName) throws IOException {
		FileInputStream fileinputstream=new FileInputStream(filepath);
		Workbook workbook=new XSSFWorkbook(fileinputstream);
		Sheet sheet=workbook.getSheet(SheetName);
		int row=sheet.getLastRowNum();
		int col=sheet.getRow(0).getLastCellNum();
		if(sheet==null) 
			System.out.println("sheet with name"+SheetName+" not found.");
		
		for(Row rowcount:sheet) {
			for(Cell colcount:rowcount) {
				switch(colcount.getCellType()) {
				case STRING:
					System.out.println(colcount.getStringCellValue()+"\t");
					break;
				case NUMERIC:
					System.out.println(colcount.getNumericCellValue()+"\t");
					break;
				case BOOLEAN:
					System.out.println(colcount.getBooleanCellValue()+"\t");
					break;
				case BLANK:
					System.out.println("BLANK"+"\t");
					break;
				default:
					System.out.println("UNKNOWN"+"\t");
					
				}
			}
			System.out.println();
		
		}
		
	}

}
