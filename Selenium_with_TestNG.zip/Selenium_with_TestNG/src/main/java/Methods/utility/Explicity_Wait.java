package Methods.utility;

import java.time.Duration;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Explicity_Wait {
	public static void explictwait(WebDriver driver,WebElement element, Duration timeout) {
		new WebDriverWait(driver,timeout).ignoring(StaleElementReferenceException.class)
		   .until(ExpectedConditions.elementToBeClickable(element));
		   element.click();
	}
	
	
	public static void visibilityof(WebDriver driver,WebElement element,Duration timeout) {
		WebDriverWait wait=new WebDriverWait(driver,timeout);
		wait.until(ExpectedConditions.visibilityOf(element));
		element.getText();
	}

	public static void alertpresent(WebDriver driver,Duration timeout) {
		new WebDriverWait(driver,timeout).ignoring(StaleElementReferenceException.class)
		.until(ExpectedConditions.alertIsPresent());
		
		
}
}